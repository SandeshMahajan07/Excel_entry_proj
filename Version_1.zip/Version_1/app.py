from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from openpyxl import load_workbook
from datetime import datetime

app = Flask(__name__)
CORS(app)

EXCEL_FILE = 'HC_Billing.xlsx'
SHEET_NAME = "MPD"

@app.route('/')
def home():
    return send_file('index.html')
@app.route('/search', methods=['GET'])
def search_entry():
    key = request.args.get('key')
    value = request.args.get('value')

    if not key or not value:
        return jsonify({"error": "Missing key or value"}), 400

    try:
        wb = load_workbook(EXCEL_FILE)
        ws = wb.active

        # Read headers (first row)
        headers = [cell.value for cell in ws[1]]

        if key not in headers:
            return jsonify({"error": f"{key} not found in headers"}), 404

        key_index = headers.index(key)

        for row in ws.iter_rows(min_row=2, values_only=True):
            if str(row[key_index]).strip().lower() == value.strip().lower():
                return jsonify(dict(zip(headers, row)))

        return jsonify({"message": "No matching entry found."})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/submit', methods=['POST'])
def submit():
    data = request.get_json()
    print("📥 Parsed JSON:")
    print(data)

    try:
        wb = load_workbook(EXCEL_FILE)
        ws = wb[SHEET_NAME]

        # Step 1: Get current month name (submission time, not poDate/doj)
        now = datetime.now()
        current_month = now.strftime("%B %Y")  # e.g., "July 2025"

        # Step 2: Add headers if not present
        if ws.max_row == 1 and all(cell.value is None for cell in ws[1]):
            headers = [
                "Sl. No", "Employee No", "Recruiter", "BD Name", "Employee Name", "Mail ID", "Client",
                "Staffing Type", "Frequency", "CTC", "PO Rate", "DOJ", "DOL", "Designation",
                "PO Number", "PO Date", "PO Start Date", "PO End Date", "Timesheet Approval",
                "Invoice Number", "Invoice Amount", "Invoice Date", "Invoice Status",
                "Billed Amount", "Payment Status"
            ]
            ws.append(headers)
            print("📝 Header row added!")

        # Step 3: Find the last inserted month section in column A
        last_month_found = None
        for row in reversed(range(2, ws.max_row + 1)):
            value = ws[f"A{row}"].value
            if isinstance(value, str) and any(month in value for month in [
                "January", "February", "March", "April", "May", "June", 
                "July", "August", "September", "October", "November", "December"
            ]):
                last_month_found = value.strip()
                break

        # Step 4: If month has changed, insert a blank + month label row
        if last_month_found != current_month:
            ws.append([])
            ws.append([current_month])
            print(f"📅 New month section added: {current_month}")

        # Step 5: Compute the next Sl. No
        sl_no = 1
        for row in ws.iter_rows(min_row=2, values_only=True):
            try:
                if isinstance(row[0], int) and row[0] >= sl_no:
                    sl_no = row[0] + 1
            except:
                continue

        # Step 6: Prepare the row to append
        row_data = [
            sl_no,
            data.get("empNo"),
            data.get("recruiter"),
            data.get("bdName"),
            data.get("empName"),
            data.get("mailId"),
            data.get("client"),
            data.get("staffingType"),
            data.get("frequency"),
            data.get("ctc"),
            data.get("poRate"),
            data.get("doj"),
            data.get("dol"),
            data.get("designation"),
            data.get("poNum"),
            data.get("poDate"),
            data.get("poStart"),
            data.get("poEnd"),
            data.get("timesheet"),
            data.get("invoiceNum"),
            data.get("invoiceAmt"),
            data.get("invoiceDate"),
            data.get("invoiceStatus"),
            data.get("billedAmt"),
            data.get("paymentStatus")
        ]

        # Step 7: Append the data and save
        ws.append(row_data)
        wb.save(EXCEL_FILE)

        print("✅ Data saved to Excel with month-wise grouping")
        return jsonify({"message": f"✅ Data saved under {current_month}!"})

    except Exception as e:
        print(f"❌ Error saving to Excel: {e}")
        return jsonify({"message": f"❌ Failed to save data: {e}"}), 500


if __name__ == '__main__':
    app.run(debug=True)
